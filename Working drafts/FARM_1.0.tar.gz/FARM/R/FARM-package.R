#' @importFrom Rcpp evalCpp
#' @importFrom ape reorder.phylo
#' @export NewTip DropTip TheOriginOfSpecies makePhy Arisal parameters getTargets
#' @export extinct BuildWorld Diffusion Extinction RunSim speciate Speciation SpeciationTakeOver
#' @export TakeOver sub.TakeOver RunSimUltimate RunSim2 RunSimUltimate2 combo_of_choice
#' @useDynLib FARM
NULL
